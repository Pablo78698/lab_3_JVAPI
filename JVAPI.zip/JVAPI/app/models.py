from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    Id = Column(Integer, primary_key=True, index=True)
    Login = Column(String(150), unique=True, nullable=False, index=True)
    PassHash = Column(String(300), nullable=False)
