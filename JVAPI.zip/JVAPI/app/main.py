from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import sqlite3, hashlib
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

def db():
    c = sqlite3.connect("users.db"); c.row_factory = sqlite3.Row; return c

con=db()
con.execute("CREATE TABLE IF NOT EXISTS User (Id INTEGER PRIMARY KEY AUTOINCREMENT, Login TEXT UNIQUE, PassHash TEXT)")
con.commit(); con.close()

class User(BaseModel):
    Login: str
    PassHash: str

def hash_pwd(p): return hashlib.sha256(p.encode()).hexdigest()

@app.post("/user")
def create_user(u:User):
    try:
        c=db()
        c.execute("INSERT INTO User (Login,PassHash) VALUES (?,?)",(u.Login,hash_pwd(u.PassHash))); c.commit()
        return {"status":"User created"}
    except sqlite3.IntegrityError: raise HTTPException(400,"Login exists")

@app.get("/user/{id}")
def get_user(id:int):
    c=db(); r=c.execute("SELECT * FROM User WHERE Id=?",(id,)).fetchone()
    if r: return dict(r)
    raise HTTPException(404,"User not found")

@app.get("/users")
def all_users():
    c=db(); return [dict(r) for r in c.execute("SELECT * FROM User")]

@app.put("/user/{id}")
def upd_user(id:int,u:User):
    c=db(); r=c.execute("UPDATE User SET Login=?,PassHash=? WHERE Id=?",(u.Login,hash_pwd(u.PassHash),id)); c.commit()
    if r.rowcount: return {"status":"User updated"}
    raise HTTPException(404,"User not found")

@app.delete("/user/{id}")
def del_user(id:int):
    c=db(); r=c.execute("DELETE FROM User WHERE Id=?",(id,)); c.commit()
    if r.rowcount: return {"status":"User deleted"}
    raise HTTPException(404,"User not found")
