from pydantic import BaseModel, Field
from typing import Optional

class UserCreate(BaseModel):
    Login: str = Field(..., min_length=3)
    PassHash: str = Field(..., min_length=8)

class UserUpdate(BaseModel):
    Login: Optional[str]
    PassHash: Optional[str]

class UserOut(BaseModel):
    Id: int
    Login: str
    class Config: orm_mode = True
