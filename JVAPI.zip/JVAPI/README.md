## FastAPI User CRUD Service

### Run
```sh
pip install -r requirements.txt
uvicorn app.main:app --reload
```
